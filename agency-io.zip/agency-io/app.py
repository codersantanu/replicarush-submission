import os
from flask import Flask, request, jsonify
from flask_cors import CORS
import google.generativeai as genai
from dotenv import load_dotenv
import json

# Load environment variables
load_dotenv('.env.local')
load_dotenv()

app = Flask(__name__)
CORS(app)

# Configure Gemini
api_key = os.getenv('GEMINI_API_KEY')
if api_key:
    genai.configure(api_key=api_key)

@app.route('/api/generate-scope', methods=['POST'])
def generate_scope():
    try:
        data = request.json
        idea = data.get('idea')
        
        if not idea:
            return jsonify({'success': False, 'error': 'No idea provided'}), 400

        if not api_key:
             # Fallback mock response if no API key
            return jsonify({
                'success': True,
                'data': {
                    'tech_stack': ['React', 'Flask', 'PostgreSQL', 'Docker'],
                    'features': ['User Authentication', 'Dashboard', 'Payment Processing', 'Admin Panel'],
                    'timeline': '4-6 weeks'
                }
            })

        model = genai.GenerativeModel('gemini-pro')
        prompt = f"""
        Generate a technical scope for the following app idea: "{idea}"
        
        Return ONLY a JSON object with the following structure:
        {{
            "tech_stack": ["list", "of", "technologies"],
            "features": ["list", "of", "key", "features"],
            "timeline": "estimated timeline string"
        }}
        """
        
        response = model.generate_content(prompt)
        text = response.text
        
        # Clean up potential markdown code blocks
        if text.startswith('```json'):
            text = text[7:-3]
        elif text.startswith('```'):
            text = text[3:-3]
            
        result = json.loads(text)
        
        return jsonify({
            'success': True,
            'data': result
        })

    except Exception as e:
        print(f"Error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)
