import React from 'react';
import { CheckCircle2 } from 'lucide-react';

export const LegacySection: React.FC = () => {
  const benefits = [
    "Reduce development time by 50%",
    "Pixel-perfect implementation",
    "Enterprise-grade security",
    "Scalable architecture default"
  ];

  return (
    <section className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-3xl md:text-5xl font-bold text-gray-900 mb-6 leading-tight">
              Stop wrestling with <span className="text-brand-600">legacy codebases</span>
            </h2>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              Our modern approach allows you to bypass technical debt and focus on what matters: delivering value to your customers. We handle the complexity so you don't have to.
            </p>
            
            <div className="space-y-4">
              {benefits.map((benefit, index) => (
                <div key={index} className="flex items-center gap-3">
                  <CheckCircle2 className="text-brand-600 flex-shrink-0" size={20} />
                  <span className="text-gray-700 font-medium">{benefit}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="relative">
            <div className="absolute -inset-4 bg-brand-200 rounded-3xl blur-2xl opacity-30"></div>
            <div className="relative bg-white rounded-2xl shadow-xl p-8 border border-gray-100 overflow-hidden">
               <div className="absolute top-0 right-0 w-64 h-64 bg-brand-50 rounded-full -translate-y-1/2 translate-x-1/2"></div>
               <div className="space-y-6 relative z-10">
                  <div className="h-4 w-1/3 bg-gray-100 rounded"></div>
                  <div className="h-32 w-full bg-brand-50/50 rounded-xl border border-brand-100 flex items-center justify-center">
                    <div className="text-brand-300 font-mono text-sm">Code Visualization</div>
                  </div>
                  <div className="space-y-2">
                    <div className="h-4 w-full bg-gray-50 rounded"></div>
                    <div className="h-4 w-5/6 bg-gray-50 rounded"></div>
                    <div className="h-4 w-4/6 bg-gray-50 rounded"></div>
                  </div>
               </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};