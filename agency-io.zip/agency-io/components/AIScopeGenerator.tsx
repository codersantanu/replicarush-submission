import React, { useState } from 'react';
import { Sparkles, Loader2, ArrowRight, Check } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from './Button';

interface ScopeResult {
  tech_stack: string[];
  features: string[];
  timeline: string;
}

export const AIScopeGenerator: React.FC = () => {
  const [idea, setIdea] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<ScopeResult | null>(null);

  const handleGenerate = async () => {
    if (!idea.trim()) return;
    
    setIsLoading(true);
    setResult(null);

    try {
      const response = await fetch('http://localhost:5000/api/generate-scope', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idea }),
      });
      
      const data = await response.json();
      if (data.success) {
        setResult(data.data);
      }
    } catch (error) {
      console.error("Failed to generate scope", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <section className="py-24 bg-gray-900 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
        <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-brand-600/20 rounded-full blur-[100px]"></div>
        <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] bg-blue-600/20 rounded-full blur-[100px]"></div>
      </div>

      <div className="max-w-4xl mx-auto px-4 relative z-10">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-900/50 border border-brand-700 text-brand-300 text-sm font-medium mb-6">
            <Sparkles size={14} />
            <span className="uppercase tracking-wide">AI Powered</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">Instant Scope Generator</h2>
          <p className="text-gray-400 text-lg max-w-xl mx-auto">
            Describe your dream app idea below, and our AI will instantly generate a technical stack and feature roadmap.
          </p>
        </div>

        <div className="bg-white/5 backdrop-blur-lg border border-white/10 rounded-2xl p-2 md:p-4 mb-12">
          <div className="flex flex-col md:flex-row gap-4">
            <input 
              type="text" 
              value={idea}
              onChange={(e) => setIdea(e.target.value)}
              placeholder="e.g., A marketplace for renting vintage cameras..."
              className="flex-1 bg-transparent border-none text-white placeholder-gray-500 focus:ring-0 text-lg px-4 py-3"
              onKeyDown={(e) => e.key === 'Enter' && handleGenerate()}
            />
            <Button 
              onClick={handleGenerate} 
              disabled={isLoading || !idea}
              className="md:w-auto w-full"
            >
              {isLoading ? <Loader2 className="animate-spin w-5 h-5" /> : 'Generate Plan'}
            </Button>
          </div>
        </div>

        <AnimatePresence>
          {result && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="bg-gray-800 border border-gray-700 rounded-2xl overflow-hidden shadow-2xl"
            >
              <div className="grid md:grid-cols-2">
                <div className="p-8 border-b md:border-b-0 md:border-r border-gray-700">
                  <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
                    <span className="w-1 h-6 bg-brand-500 rounded-full"></span>
                    Recommended Stack
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {result.tech_stack.map((tech, i) => (
                      <span key={i} className="px-3 py-1 bg-gray-700 rounded-lg text-gray-300 text-sm border border-gray-600">
                        {tech}
                      </span>
                    ))}
                  </div>

                  <div className="mt-8">
                     <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                      <span className="w-1 h-6 bg-blue-500 rounded-full"></span>
                      Estimated Timeline
                    </h3>
                    <p className="text-blue-400 font-mono text-lg">{result.timeline}</p>
                  </div>
                </div>

                <div className="p-8 bg-gray-800/50">
                  <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
                    <span className="w-1 h-6 bg-emerald-500 rounded-full"></span>
                    Key Features
                  </h3>
                  <ul className="space-y-3">
                    {result.features.map((feature, i) => (
                      <li key={i} className="flex items-start gap-3 text-gray-300">
                        <Check className="w-5 h-5 text-emerald-500 flex-shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
              <div className="bg-brand-900/20 p-4 text-center border-t border-gray-700">
                <button className="text-brand-400 text-sm font-medium hover:text-brand-300 flex items-center justify-center gap-1 mx-auto">
                  Book a call to discuss this plan <ArrowRight size={14} />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
};