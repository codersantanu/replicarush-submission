import React from 'react';
import { Search, PenTool, Code2 } from 'lucide-react';
import { motion } from 'framer-motion';

export const ProcessSection: React.FC = () => {
  const steps = [
    {
      id: "01",
      title: "Explore",
      description: "We dive deep into your business requirements to map out the perfect solution.",
      icon: Search,
      color: "bg-blue-50 text-blue-600",
    },
    {
      id: "02",
      title: "Design",
      description: "Our UX/UI experts craft stunning, user-centric interfaces that align with your brand identity.",
      icon: PenTool,
      color: "bg-purple-50 text-purple-600",
    },
    {
      id: "03",
      title: "Build",
      description: "We develop your product using modern tech stacks, ensuring performance and scalability.",
      icon: Code2,
      color: "bg-emerald-50 text-emerald-600",
    }
  ];

  const iconVariants = {
    rest: { 
      y: 0, 
      filter: "drop-shadow(0px 0px 0px rgba(0,0,0,0))" 
    },
    hover: { 
      y: -10, 
      filter: "drop-shadow(0px 10px 15px rgba(0,0,0,0.2))",
      transition: { 
        type: "spring", 
        stiffness: 300, 
        damping: 20 
      }
    }
  };

  const cardVariants = {
    rest: { y: 0 },
    hover: { 
      y: -5,
      transition: { duration: 0.3 }
    }
  };

  return (
    <section className="py-24 bg-white" id="process">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <h2 className="text-3xl md:text-5xl font-bold text-gray-900">How we work</h2>
        </div>

        <div className="relative">
          {/* Animated Line (Desktop) */}
          <div className="hidden lg:block absolute top-1/2 left-0 w-full h-0.5 bg-gray-100 -translate-y-1/2 z-0">
            <motion.div 
              initial={{ width: "0%" }}
              whileInView={{ width: "100%" }}
              viewport={{ once: true }}
              transition={{ duration: 1.5, ease: "easeInOut" }}
              className="h-full bg-gradient-to-r from-blue-500 via-purple-500 to-emerald-500"
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 relative z-10">
            {steps.map((step, index) => (
              <motion.div 
                key={step.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.2 }}
                className="relative group"
              >
                <motion.div 
                  initial="rest"
                  whileHover="hover"
                  variants={cardVariants}
                  className="bg-white p-8 rounded-2xl shadow-lg border border-gray-100 h-full flex flex-col items-center text-center"
                >
                  <motion.div 
                    variants={iconVariants}
                    className={`w-16 h-16 ${step.color} rounded-2xl flex items-center justify-center mb-6 shadow-sm`}
                  >
                    <step.icon size={32} />
                  </motion.div>
                  <div className="inline-block px-3 py-1 bg-gray-50 rounded-full text-xs font-bold text-gray-500 mb-4 border border-gray-100">
                    Step {step.id}
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-4">{step.title}</h3>
                  <p className="text-gray-600 leading-relaxed">
                    {step.description}
                  </p>
                </motion.div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};