import React from 'react';
import { Check, X, Minus } from 'lucide-react';

export const ComparisonSection: React.FC = () => {
  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-gray-900">Why choose us?</h2>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b-2 border-gray-100">
                <th className="py-6 px-4 text-gray-500 font-medium uppercase tracking-wider text-sm">Criteria</th>
                <th className="py-6 px-4 text-gray-900 font-bold text-lg text-center w-1/4">Agencies</th>
                <th className="py-6 px-4 text-gray-900 font-bold text-lg text-center w-1/4">Freelancers</th>
                <th className="py-6 px-4 text-brand-600 font-bold text-xl text-center w-1/4 bg-brand-50/30 rounded-t-2xl">Agency.io</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-gray-50 group hover:bg-gray-50/50 transition-colors">
                <td className="py-6 px-4 font-semibold text-gray-700">Delivery Speed</td>
                <td className="py-6 px-4 text-center text-gray-500">Slow (Months)</td>
                <td className="py-6 px-4 text-center text-gray-500">Inconsistent</td>
                <td className="py-6 px-4 text-center text-brand-700 font-bold bg-brand-50/30">Rapid (Weeks)</td>
              </tr>
              <tr className="border-b border-gray-50 group hover:bg-gray-50/50 transition-colors">
                <td className="py-6 px-4 font-semibold text-gray-700">Code Quality</td>
                <td className="py-6 px-4 text-center text-gray-500">Variable</td>
                <td className="py-6 px-4 text-center text-gray-500">Variable</td>
                <td className="py-6 px-4 text-center text-brand-700 font-bold bg-brand-50/30 flex justify-center items-center gap-2">
                  Standardized & Audited
                </td>
              </tr>
              <tr className="border-b border-gray-50 group hover:bg-gray-50/50 transition-colors">
                <td className="py-6 px-4 font-semibold text-gray-700">Design</td>
                <td className="py-6 px-4 text-center text-gray-500">Outsourced</td>
                <td className="py-6 px-4 text-center text-gray-500">Limited</td>
                <td className="py-6 px-4 text-center text-brand-700 font-bold bg-brand-50/30">In-house Expert Choice</td>
              </tr>
              <tr className="group hover:bg-gray-50/50 transition-colors">
                <td className="py-6 px-4 font-semibold text-gray-700">Scalability</td>
                <td className="py-6 px-4 text-center text-gray-500">Often Overlooked</td>
                <td className="py-6 px-4 text-center text-gray-500">Rarely Priority</td>
                <td className="py-6 px-4 text-center text-brand-700 font-bold bg-brand-50/30 rounded-b-2xl">Built-in Foundation</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
};