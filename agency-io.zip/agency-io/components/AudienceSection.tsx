import React from 'react';
import { Rocket, ShieldCheck, ArrowRight } from 'lucide-react';

export const AudienceSection: React.FC = () => {
  return (
    <section className="py-24 bg-white" id="services">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-gray-900 mb-6">Tailored for every stage</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Whether you are just starting out or scaling up, we have the specialized workflows to support your growth.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Startup Card */}
          <div className="group p-8 rounded-2xl border border-gray-200 hover:border-brand-200 hover:shadow-xl hover:shadow-brand-500/10 transition-all duration-300 bg-white">
            <div className="w-14 h-14 bg-amber-100 rounded-xl flex items-center justify-center mb-6 text-amber-600 group-hover:scale-110 transition-transform">
              <Rocket size={28} />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Startups</h3>
            <p className="text-gray-600 mb-8 leading-relaxed">
              Move fast and break nothing. Get your MVP to market in record time with our rapid deployment pipelines and lean development methodologies.
            </p>
            <a href="#" className="inline-flex items-center text-amber-600 font-semibold hover:text-amber-700">
              Learn more <ArrowRight size={16} className="ml-2 group-hover:translate-x-1 transition-transform" />
            </a>
          </div>

          {/* Enterprise Card */}
          <div className="group p-8 rounded-2xl border border-gray-200 hover:border-brand-200 hover:shadow-xl hover:shadow-brand-500/10 transition-all duration-300 bg-white">
            <div className="w-14 h-14 bg-blue-100 rounded-xl flex items-center justify-center mb-6 text-blue-600 group-hover:scale-110 transition-transform">
              <ShieldCheck size={28} />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Enterprises</h3>
            <p className="text-gray-600 mb-8 leading-relaxed">
              Robust, compliant, and scalable. We build systems that can handle millions of users from day one with bank-grade security protocols.
            </p>
            <a href="#" className="inline-flex items-center text-blue-600 font-semibold hover:text-blue-700">
              Learn more <ArrowRight size={16} className="ml-2 group-hover:translate-x-1 transition-transform" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};