import React, { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { Rocket, ShieldCheck, Code2, Layers, Cpu } from 'lucide-react';

export const BentoGrid: React.FC = () => {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"]
  });
  const y = useTransform(scrollYProgress, [0, 1], [0, 100]);

  const iconVariants = {
    rest: { 
      y: 0, 
      filter: "drop-shadow(0px 0px 0px rgba(0,0,0,0))" 
    },
    hover: { 
      y: -10, 
      filter: "drop-shadow(0px 10px 15px rgba(0,0,0,0.2))",
      transition: { 
        type: "spring", 
        stiffness: 300, 
        damping: 20 
      }
    }
  };

  const cardVariants = {
    rest: { y: 0 },
    hover: { 
      y: -5,
      transition: { duration: 0.3 }
    }
  };

  return (
    <section ref={ref} className="py-24 bg-gray-50/50" id="services">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Stop wrestling with <span className="text-brand-600">legacy code</span>
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Our modern approach allows you to bypass technical debt. We use a modular architecture that scales with your ambition.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 grid-rows-2 gap-6 h-auto md:h-[600px]">
          
          {/* Card 1: Startups (Large Left) */}
          <motion.div 
            initial="rest"
            whileHover="hover"
            variants={cardVariants}
            className="md:col-span-2 md:row-span-2 bg-white rounded-3xl p-8 md:p-12 border border-gray-100 shadow-sm hover:shadow-xl hover:shadow-brand-500/10 transition-shadow duration-300 relative overflow-hidden group"
          >
             <motion.div style={{ y }} className="absolute top-0 right-0 w-64 h-64 bg-amber-50 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 group-hover:bg-amber-100 transition-colors"></motion.div>
             
             <div className="relative z-10 h-full flex flex-col justify-between">
                <div>
                  <motion.div 
                    variants={iconVariants}
                    className="w-14 h-14 bg-amber-100 rounded-2xl flex items-center justify-center mb-6 text-amber-600"
                  >
                    <Rocket size={28} />
                  </motion.div>
                  <h3 className="text-3xl font-bold text-gray-900 mb-4">Startups & MVPs</h3>
                  <p className="text-gray-600 text-lg leading-relaxed max-w-md">
                    Move fast and break nothing. We build rapid deployment pipelines that get your product to market in weeks, not months.
                  </p>
                </div>
                
                <div className="mt-8 grid grid-cols-2 gap-4">
                  <div className="bg-gray-50 p-4 rounded-xl border border-gray-100">
                    <div className="text-2xl font-bold text-gray-900">2 Weeks</div>
                    <div className="text-sm text-gray-500">Avg. Prototype</div>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-xl border border-gray-100">
                    <div className="text-2xl font-bold text-gray-900">100%</div>
                    <div className="text-sm text-gray-500">Ownership</div>
                  </div>
                </div>
             </div>
          </motion.div>

          {/* Card 2: Enterprise (Top Right) */}
          <motion.div 
            initial="rest"
            whileHover="hover"
            variants={cardVariants}
            className="bg-white rounded-3xl p-8 border border-gray-100 shadow-sm hover:shadow-xl hover:shadow-blue-500/10 transition-shadow duration-300 relative overflow-hidden group"
          >
            <motion.div style={{ y }} className="absolute top-0 right-0 w-32 h-32 bg-blue-50 rounded-full blur-2xl -translate-y-1/2 translate-x-1/2"></motion.div>
            <div className="relative z-10">
              <motion.div 
                variants={iconVariants}
                className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mb-4 text-blue-600"
              >
                <ShieldCheck size={24} />
              </motion.div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Enterprise Scale</h3>
              <p className="text-sm text-gray-600">
                Bank-grade security and compliance ready architecture for millions of users.
              </p>
            </div>
          </motion.div>

          {/* Card 3: Tech Stack (Bottom Right) */}
          <motion.div 
            initial="rest"
            whileHover="hover"
            variants={cardVariants}
            className="bg-gray-900 rounded-3xl p-8 border border-gray-800 shadow-sm hover:shadow-xl hover:shadow-purple-500/20 transition-shadow duration-300 relative overflow-hidden group"
          >
             <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-brand-500 to-blue-500"></div>
             <div className="relative z-10 text-white">
              <motion.div 
                variants={iconVariants}
                className="w-12 h-12 bg-gray-800 rounded-xl flex items-center justify-center mb-4 text-brand-400"
              >
                <Cpu size={24} />
              </motion.div>
              <h3 className="text-xl font-bold mb-2">Modern Stack</h3>
              <p className="text-sm text-gray-400">
                React, Python, Node, Go. We choose the right tool for the job.
              </p>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
};