import React from 'react';

export const LogoMarquee: React.FC = () => {
  const logos = [
    "TechNova", "Globex", "Acme Corp", "Soylent", "Initech", "Umbrella", "Cyberdyne", "Stark Ind", "Wayne Ent"
  ];

  return (
    <div className="w-full py-12 border-y border-gray-100 bg-white/50 backdrop-blur-sm overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 mb-8">
        <p className="text-center text-sm font-semibold text-gray-400 uppercase tracking-wider">Trusted by innovative teams</p>
      </div>
      <div className="relative flex overflow-x-hidden group">
        <div className="animate-marquee whitespace-nowrap flex gap-16 px-8 min-w-full flex-shrink-0">
          {[...logos, ...logos, ...logos].map((logo, index) => (
            <span 
              key={index} 
              className="text-2xl font-bold text-gray-300 hover:text-brand-600 transition-colors cursor-default select-none"
            >
              {logo}
            </span>
          ))}
        </div>
        
        <div className="animate-marquee whitespace-nowrap flex gap-16 px-8 min-w-full flex-shrink-0">
           {[...logos, ...logos, ...logos].map((logo, index) => (
            <span 
              key={`clone-${index}`} 
              className="text-2xl font-bold text-gray-300 hover:text-brand-600 transition-colors cursor-default select-none"
            >
              {logo}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};