import React from 'react';
import { Play } from 'lucide-react';
import { Button } from './Button';
import { motion, useScroll, useTransform } from 'framer-motion';

export const Hero: React.FC = () => {
  const { scrollY } = useScroll();
  const y = useTransform(scrollY, [0, 1000], [0, 500]);

  return (
    <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden pt-20">
      {/* Aurora Background */}
      <div className="absolute inset-0 w-full h-full bg-white -z-20"></div>
      <motion.div style={{ y }} className="absolute top-0 left-1/4 w-96 h-96 bg-brand-200 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-blob -z-10"></motion.div>
      <motion.div style={{ y }} className="absolute top-0 right-1/4 w-96 h-96 bg-purple-200 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-blob animation-delay-2000 -z-10"></motion.div>
      <motion.div style={{ y }} className="absolute -bottom-32 left-1/3 w-96 h-96 bg-pink-200 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-blob animation-delay-4000 -z-10"></motion.div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/50 backdrop-blur-md border border-brand-100 text-brand-600 text-sm font-medium mb-8 shadow-sm"
        >
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-brand-500"></span>
          </span>
          Accepting new projects for Q1
        </motion.div>

        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="text-5xl md:text-7xl lg:text-8xl font-bold tracking-tight text-gray-900 mb-8 max-w-5xl mx-auto leading-none"
        >
          Turn your expertise into <br className="hidden md:block" />
          <span className="gradient-text">AI-powered Reality</span>
        </motion.h1>

        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="text-xl text-gray-600 max-w-2xl mx-auto mb-10 leading-relaxed"
        >
          We help ambitious brands and startups design, build, and scale world-class digital products with a focus on comprehensive design and robust engineering.
        </motion.p>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <Button size="lg" withArrow className="shadow-brand-500/25 shadow-xl">Start Project</Button>
          <button className="flex items-center gap-2 px-8 py-4 text-gray-700 font-medium hover:text-brand-600 transition-colors group rounded-full bg-white/50 backdrop-blur-sm border border-gray-200 hover:border-brand-200">
            <div className="w-8 h-8 rounded-full bg-brand-50 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Play size={14} className="fill-brand-600 text-brand-600 ml-0.5" />
            </div>
            Watch Reel
          </button>
        </motion.div>
      </div>
    </section>
  );
};