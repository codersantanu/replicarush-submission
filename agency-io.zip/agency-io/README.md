<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://github.com/user-attachments/assets/0aa67016-6eaf-458a-adb2-6e31a0763ed6" />
</div>

# Agency.io - AI-Powered Reality

A modern, high-performance landing page for a digital agency, featuring advanced animations and a premium design.

## Features

- **Anti-Gravity Interactions:** Advanced physics-based hover effects on icons for a weightless feel.
- **Parallax Scrolling:** Subtle depth effects in the Hero and Bento Grid sections using Framer Motion to enhance visual engagement.
- **Dark/Light Mode:** Seamless theme toggle with persistent state (saved to localStorage) and smooth icon transitions.
- **Responsive Design:** Fully responsive layout optimized for all device sizes.
- **Modern UI:** Glassmorphism, aurora gradients, and refined typography.

## Tech Stack

- **Framework:** React 18
- **Language:** TypeScript
- **Styling:** Tailwind CSS
- **Animation:** Framer Motion
- **Icons:** Lucide React
- **Build Tool:** Vite

## Getting Started

Follow these instructions to set up the project locally.

### Prerequisites

- Node.js (v18 or higher recommended)
- npm or yarn

### Installation

1. **Clone the repository** (if applicable) or navigate to the project directory.

2. **Install dependencies:**
   ```bash
   npm install
   ```
   
3. **Run the development server:**
   ```bash
   npm run dev
   ```

4. **Open your browser:**
   Navigate to `http://localhost:5173` (or the port shown in your terminal) to view the app.

## Building for Production

To build the app for production:

```bash
npm run build
```

The built files will be in the `dist` directory.
