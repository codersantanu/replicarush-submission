import React from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { LogoMarquee } from './components/LogoMarquee';
import { BentoGrid } from './components/BentoGrid';
import { ProcessSection } from './components/ProcessSection';
import { ComparisonSection } from './components/ComparisonSection';
import { AIScopeGenerator } from './components/AIScopeGenerator';
import { Footer } from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-white dark:bg-gray-950 dark:text-white transition-colors duration-300">
      <Navbar />
      <main>
        <Hero />
        <LogoMarquee />
        <BentoGrid />
        <ProcessSection />
        <AIScopeGenerator />
        <ComparisonSection />
      </main>
      <Footer />
    </div>
  );
}

export default App;